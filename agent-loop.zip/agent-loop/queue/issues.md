# Issue 队列 —— 主脑的短期记忆

> **任务从这来，结论回这去。**
> 这份文件是整个循环的枢纽：PLAN 读它，REVIEW 改它，下一轮 PLAN 再读它。
> 人类可以直接编辑，也可以让 Agent 编辑。

---

## 怎么写一张卡

复制下面那张卡的格式。**关键在「验收标准」和「判据自检」两栏**——没有它们，门禁会拦下这张卡。

## 状态
- `[ ]` = open（待办）
- `[x]` = 已关闭（会归档到 `queue/archive/`）

---

## [ ] #1 示例：给周报脚本加一个「漏条目就失败」的检查

- **priority**: P1
- **created**: 2026-10-27
- **area**: 工具链
- **source**: 手工
- **验收标准**:
  1. 跑 `python3 scripts/check_report.py --input sample_missing.md` 退出码非 0，且输出包含 "MISSING"
  2. 跑 `python3 scripts/check_report.py --input sample_ok.md` 退出码 0，且无告警
  3. 新检查接入 `make check`，`make check` 整体退出码仍为 0
- **判据自检**: 已知答案为「否」的输入是 `sample_missing.md`（少一条数据）。跑验收标准 1，确认它变红。
- **沉淀层级**: 待定（关单时填）

### 背景
周报脚本目前只统计条目数，从不检查该有的条目在不在。已经漏过一次，漏了没人发现。

### 交付物
- `scripts/check_report.py`
- `sample_missing.md` / `sample_ok.md` 两个测试样例
- `Makefile` 里接上 `check`

### 不许碰
- 不要动 `scripts/report_render.py` 的渲染逻辑
- 不要提交 / 推送（除非明确授权）

---

<!--
更多卡往下加。每张卡一个 ## [ ] #N 标题。
id 不要重复。关单后会被自动归档到 queue/archive/YYYY-MM.md。
-->
