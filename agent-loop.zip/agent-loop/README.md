# Agent Loop —— 路线 2 骨架

> 一个能无人值守自己转的 Agent 循环。
> PLAN → DO → REVIEW → 回流，每轮把上一轮的经验变成下一轮的输入。

> 📖 **第一次用请先看 `使用说明.md`**（操作手册：现在该敲什么）。
> 这份 README 讲的是架构和原理。

---

## 是什么

```
   ┌──────────────────────────────────────────┐
   │  queue/issues.md   ← 队列 = 主脑的短期记忆 │
   └───────────────┬──────────────────────────┘
                   │
     ┌─────────────▼─────────────┐
     │  Stage 1 · PLAN  （主脑）  │  强模型，读队列 → 拆出任务卡
     └─────────────┬─────────────┘
                   │ 任务卡（干净的上下文）
     ┌─────────────▼─────────────┐
     │  Stage 2 · DO （执行器）   │  便宜模型，拿卡就干，干完就退出
     └─────────────┬─────────────┘
                   │ 结果
     ┌─────────────▼─────────────┐
     │  Stage 3 · REVIEW（主脑）  │  对照验收标准判定
     └─────────────┬─────────────┘
                   │
          通过 → 关单 + 归档 + 回流 MEMORY
          不通过 → 带根因退回队列
                   │
                   └──► 下一轮 PLAN（这就是 Loop）
```

**三个阶段的上下文彼此隔离。** 主脑不背执行器的脏活，执行器不背主脑的历史。
这是文章里「主脑和执行器两套上下文配置」的最小复刻。

---

## 装

```bash
cd agent-loop
chmod +x bin/*.sh
./bin/doctor.sh          # 自检
```

### 接你的客户端

编辑 `config.sh`：

```bash
# Claude Code
MAIN_BIN="claude";   MAIN_MODE="print"
WORKER_BIN="claude"; WORKER_MODE="print"

# Codex CLI
MAIN_BIN="codex";    MAIN_MODE="exec"
```

**不同客户端的参数名会变版本。** 先跑 `<BIN> --help` 确认。
`MAIN_MODE` 三选一：`print`（`claude -p`）/ `exec`（`codex exec`）/ `stdin`（读 stdin，最通用）。

**主脑和执行器可以不是同一个客户端。** 文章的做法是主脑用强模型、执行器用便宜的。
但第一周建议先都用同一个，跑通了再拆。

---

## 跑

```bash
# 第一步：干跑。不调用任何 agent，只看组装得对不对
./bin/run.sh --dry-run

# 第二步：真跑一轮
./bin/run.sh

# 看这一轮发生了什么
cat state/last_run.md
ls logs/
```

### 装定时任务

```bash
./bin/install-cron.sh              # 每天 09:17
./bin/install-cron.sh --every 30m  # 每 30 分钟
./bin/install-cron.sh --at "*/30 8-22 * * *"   # 自定义 cron 表达式
./bin/install-cron.sh --uninstall
```

> **cron 最大的坑是 PATH。** 脚本会自动探测 CLI 绝对路径写进 crontab。
> 如果还是报「找不到命令」，去 `config.sh` 把 `MAIN_BIN_ABS` / `WORKER_BIN_ABS` 设成绝对路径。

macOS 用户如果不想用 cron，可以用 launchd，README 末尾有。

---

## 写卡片

编辑 `queue/issues.md`，加一张卡：

```markdown
## [ ] #2 标题
- **priority**: P1
- **created**: 2026-10-27
- **验收标准**:
  1. <可判定的条件，最好写成"跑什么命令、看到什么结果">
  2. ...
- **判据自检**: 已知答案为「否」的输入是 ______。跑一遍验收标准，确认它变红。
```

**「验收标准」和「判据自检」缺一不可。** 缺了门禁会拦下这张卡（`queue.sh check` 可查）。

> 判据自检为什么重要：大部分「看起来在工作」的检查其实是坏的——
> 跳过的步骤被当成通过、名单过期导致整批任务静默跳过。
> 它们的共同点是**都是绿的、都不报错**。
> **永远不会变红的检查，等于没写。**

### 关单的硬规矩

```bash
./bin/queue.sh close 2 --root-cause "检查只数条目不查缺漏" --hardening script --evidence "sample_missing.md 退出码 1"
```

三个参数都必填：

- `--root-cause` 根因，不是「修了」
- `--hardening` 沉淀到哪一层：`script` > `test` > `lint` > `rule` > `manual`
- `--evidence` 验证证据

**默认往 `script` / `test` 放。** 只写进规则文件的教训，过阵子会以别的形式再冒出来。
判断是否真修好的标准不是「我改了」，是「**机制上不可能再发生**」。

---

## 目录

```
agent-loop/
├── config.sh              改这个文件就够了
├── bin/
│   ├── run.sh             一轮循环：PLAN → DO → REVIEW → 回流
│   ├── queue.sh           队列工具（list/next/close/reopen/check）
│   ├── doctor.sh          自检
│   └── install-cron.sh    装定时任务
├── prompts/
│   ├── mainbrain.md       主脑：拆任务（PLAN）
│   ├── worker.md          执行器：照卡干活（DO）
│   └── review.md          主脑：验收（REVIEW）
├── queue/
│   ├── issues.md          任务队列
│   └── archive/           已关闭的卡自动归档
├── memory/
│   ├── AGENTS.md          长期背景（静态 Context）
│   └── MEMORY.md          滚动记忆（动态 Context）
├── state/
│   ├── dispatch/          本轮的任务卡、中间产物
│   └── last_run.md        上次跑的摘要
└── logs/                  每一轮的完整日志
```

---

## 排障

| 症状 | 大概率原因 |
|---|---|
| cron 里报「找不到 claude」 | PATH 问题 → `config.sh` 填绝对路径 |
| 主脑没产出任务卡 | 卡片信息不足 → `queue.sh show <id>` 看看，缺什么补什么 |
| 每轮都是 FAIL | 验收标准不可判定 → 改成能跑命令看结果的 |
| 卡永远不动 | 门禁拦着 → `queue.sh check` |
| MEMORY 越来越臃肿 | 该瘦身了 → 见下 |
| 上一轮还在跑 | 锁没释放 → `rm -rf state/.lock`（确认没进程在跑再删） |

### 给 Agent 瘦身的指令

```
读一遍 memory/MEMORY.md，删掉已过期、已完成、已被更好结论取代的条目，
输出删除前后的对比给我确认。
```

---

## macOS 的 launchd 方案

```bash
cat > ~/Library/LaunchAgents/com.agentloop.daily.plist <<PLIST
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
  <key>Label</key><string>com.agentloop.daily</string>
  <key>ProgramArguments</key>
  <array>
    <string>/bin/bash</string>
    <string>$LOOP_ROOT/bin/run.sh</string>
  </array>
  <key>StartCalendarInterval</key>
  <dict><key>Hour</key><integer>9</integer><key>Minute</key><integer>17</integer></dict>
  <key>StandardOutPath</key><string>$LOOP_ROOT/logs/launchd.log</string>
  <key>StandardErrorPath</key><string>$LOOP_ROOT/logs/launchd.err</string>
</dict>
</plist>
PLIST

launchctl load ~/Library/LaunchAgents/com.agentloop.daily.plist
```

---

## 上线顺序（别一次做完）

1. **第 1 周**：`doctor.sh` + `run.sh --dry-run`，确认组装对了。**不装 cron。**
2. **第 2 周**：手写 2–3 张卡，手动跑 `run.sh`。看着它关单、归档、回流 MEMORY。
3. **第 3 周**：上 cron，先每天一次。
4. **第 4 周**：觉得手动触发烦了，再拆主脑 / 执行器用不同客户端和模型。

**先别做的事**：别拆多 agent、别上多模型分层、别搞语义检索、别装一堆 Skill。
这套骨架的价值不在复杂，在于**它会自己转**。
